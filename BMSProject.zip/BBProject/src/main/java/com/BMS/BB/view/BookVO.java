package com.BMS.BB.view;

public class BookVO {
	private int BOOK_ID;
	private String PHONENUMBER;
	private String BREAD_NAME;
	private int BOOK_AMOUNT;
	private int BOOK_PRICE;
	
	
	public int getBOOK_ID() {
		return BOOK_ID;
	}
	public void setBOOK_ID(int bOOK_ID) {
		BOOK_ID = bOOK_ID;
	}
	public String getPHONENUMBER() {
		return PHONENUMBER;
	}
	public void setPHONENUMBER(String pHONENUMBER) {
		PHONENUMBER = pHONENUMBER;
	}
	public String getBREAD_NAME() {
		return BREAD_NAME;
	}
	public void setBREAD_NAME(String bREAD_NAME) {
		BREAD_NAME = bREAD_NAME;
	}
	public int getBOOK_AMOUNT() {
		return BOOK_AMOUNT;
	}
	public void setBOOK_AMOUNT(int bOOK_AMOUNT) {
		BOOK_AMOUNT = bOOK_AMOUNT;
	}
	public int getBOOK_PRICE() {
		return BOOK_PRICE;
	}
	public void setBOOK_PRICE(int bOOK_PRICE) {
		BOOK_PRICE = bOOK_PRICE;
	}
}
