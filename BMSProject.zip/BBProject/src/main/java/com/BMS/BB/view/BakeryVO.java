package com.BMS.BB.view;

public class BakeryVO {
	private int BREAD_ID;
	private String BREAD_NAME;
	private int BREAD_PRICE;
	private int BREAD_AMOUNT;
	private int BREAD_OUTPUTTIME;
	
	
	public int getBREAD_ID() {
		return BREAD_ID;
	}
	public void setBREAD_ID(int bREAD_ID) {
		BREAD_ID = bREAD_ID;
	}
	public String getBREAD_NAME() {
		return BREAD_NAME;
	}
	public void setBREAD_NAME(String bREAD_NAME) {
		BREAD_NAME = bREAD_NAME;
	}
	public int getBREAD_PRICE() {
		return BREAD_PRICE;
	}
	public void setBREAD_PRICE(int bREAD_PRICE) {
		BREAD_PRICE = bREAD_PRICE;
	}
	public int getBREAD_AMOUNT() {
		return BREAD_AMOUNT;
	}
	public void setBREAD_AMOUNT(int bREAD_AMOUNT) {
		BREAD_AMOUNT = bREAD_AMOUNT;
	}
	public int getBREAD_OUTPUTTIME() {
		return BREAD_OUTPUTTIME;
	}
	public void setBREAD_OUTPUTTIME(int bREAD_OUTPUTTIME) {
		BREAD_OUTPUTTIME = bREAD_OUTPUTTIME;
	}
}
